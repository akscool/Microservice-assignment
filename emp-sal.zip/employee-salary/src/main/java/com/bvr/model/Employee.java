package com.bvr.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "employees")
public class Employee {

	private String id,name;
	private Long baseSalary;
	private Long totalSalary;
	private String startDate;
	private String endDate;
	public Long getTotalSalary() {
		return totalSalary;
	}
	public Long getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(Long baseSalary) {
		this.baseSalary = baseSalary;
	}
	public void setTotalSalary(Long totalSalary) {
		this.totalSalary = totalSalary;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
}
