package com.bvr.repository;

import org.springframework.data.repository.CrudRepository;

import com.bvr.model.Employee;

public interface EmpMongoRepo extends CrudRepository<Employee, String>{

}
