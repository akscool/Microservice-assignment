package com.bvr.controllers;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bvr.model.Employee;
import com.bvr.repository.EmpMongoRepo;
import com.bvr.repository.EmpSearchRepo;

@Controller
public class SalaryController {

	@Autowired
	EmpMongoRepo empRepository;
	
	@Autowired
	EmpSearchRepo empSearchRepository;
	
	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("empList", empRepository.findAll());
		return "emp";
	}
	
	@RequestMapping(value = "/addEmp", method = RequestMethod.POST)
	public String addEmp(@ModelAttribute Employee emp) throws Exception{
		long monthsBetween = ChronoUnit.MONTHS.between(
			     YearMonth.from(LocalDate.parse(emp.getStartDate())), 
			     YearMonth.from(LocalDate.parse(emp.getEndDate()))
			);
		//date1=new SimpleDateFormat("yyyy-mm-dd").parse(emp.getStartDate());
		//Date date2=new SimpleDateFormat("yyyy-mm-dd").parse(emp.getEndDate());

		emp.setTotalSalary(emp.getBaseSalary()+monthsBetween*1000);
		empRepository.save(emp);
		return "redirect:home";
	}
	
	@RequestMapping(value = "/search")
	public String search(Model model, @RequestParam String search) {
		model.addAttribute("empList", empSearchRepository.searchEmp(search));
		model.addAttribute("search", search);
		return "emp";
	}
}
